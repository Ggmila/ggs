// ==UserScript==
// @name         Faucet Rotator - ClaimFreeCoins.io
// @namespace    Faucet Rotator - ClaimFreeCoins.io
// @version      3
// @description  Earn free crypto auto by script
// @author       you
// @match        https://claimfreecoins.io/*
// @connect      claimfreecoins.io
// @icon         https://www.google.com/s2/favicons?sz=64&domain=claimfreecoins.io
// @noframes
// @grant        GM_setValue
// @grant        GM_getValue
// @grant        GM_xmlhttpRequest
// @antifeature  referral-link
// @downloadURL https://update.greasyfork.org/scripts/562009/Faucet%20Rotator%20-%20ClaimFreeCoinsio.user.js
// @updateURL https://update.greasyfork.org/scripts/562009/Faucet%20Rotator%20-%20ClaimFreeCoinsio.meta.js
// ==/UserScript==

// منع جميع النوافذ المنبثقة
unsafeWindow.open = function() { };

(function() {
    'use strict';

    // ===============================================================================================
    // إعدادات المستخدم
    // ===============================================================================================

    const FAUCETPAY_EMAIL = "zivinjr@gmail.com"; // بريد الفوسيت باي فقط

    const WEBSITE_LIST = [
        { url: "https://claimfreecoins.io/dogecoin-faucet/?r=zivinjr@gmail.com", coin: "dogecoin-faucet", address: FAUCETPAY_EMAIL },
        { url: "https://claimfreecoins.io/litecoin-faucet/?r=zivinjr@gmail.com", coin: "litecoin-faucet", address: FAUCETPAY_EMAIL },
        { url: "https://claimfreecoins.io/tron-faucet/?r=zivinjr@gmail.com", coin: "tron-faucet", address: FAUCETPAY_EMAIL },
        { url: "https://claimfreecoins.io/bnb-faucet/?r=zivinjr@gmail.com", coin: "bnb-faucet", address: FAUCETPAY_EMAIL },
        { url: "https://claimfreecoins.io/solana-faucet/?r=zivinjr@gmail.com", coin: "solana-faucet", address: FAUCETPAY_EMAIL },
        { url: "https://claimfreecoins.io/tether-faucet/?r=zivinjr@gmail.com", coin: "tether-faucet", address: FAUCETPAY_EMAIL },
        { url: "https://claimfreecoins.io/polygon-faucet/?r=zivinjr@gmail.com", coin: "polygon-faucet", address: FAUCETPAY_EMAIL },
        { url: "https://claimfreecoins.io/ethereum-faucet/?r=zivinjr@gmail.com", coin: "ethereum-faucet", address: FAUCETPAY_EMAIL },
        { url: "https://claimfreecoins.io/bch-faucet/?r=zivinjr@gmail.com", coin: "bch-faucet", address: FAUCETPAY_EMAIL },
        { url: "https://claimfreecoins.io/dash-faucet/?r=zivinjr@gmail.com", coin: "dash-faucet", address: FAUCETPAY_EMAIL },
        { url: "https://claimfreecoins.io/zcash-faucet/?r=zivinjr@gmail.com", coin: "zcash-faucet", address: FAUCETPAY_EMAIL },
        { url: "https://claimfreecoins.io/digibyte-faucet/?r=zivinjr@gmail.com", coin: "digibyte-faucet", address: FAUCETPAY_EMAIL },
        { url: "https://claimfreecoins.io/feyorra-faucet/?r=zivinjr@gmail.com", coin: "usdc-faucet", address: FAUCETPAY_EMAIL },
        { url: "https://claimfreecoins.io/feyorra-faucet/?r=zivinjr@gmail.com", coin: "ripple-faucet", address: FAUCETPAY_EMAIL },
        { url: "https://claimfreecoins.io/feyorra-faucet/?r=zivinjr@gmail.com", coin: "toncoin-faucet", address: FAUCETPAY_EMAIL },
        { url: "https://claimfreecoins.io/feyorra-faucet/?r=zivinjr@gmail.com", coin: "stellar-faucet", address: FAUCETPAY_EMAIL },
    ];

    const WEBSITE_CONFIG = [{
        website: ["claimfreecoins.io"],
        inputTextSelector: "#address",
        inputTextSelectorButton: null,
        defaultButtonSelectors: [".btn.btn-block.my-0[data-toggle='modal']", ".btn.btn-block.my-0"],
        captchaButtonSubmitSelector: "#login",
        allMessageSelectors: [".alert.alert-warning", ".alert.alert-success", ".alert.alert-danger", "#cf-error-details"],
        successMessageSelectors: [".alert.alert-success"],
        messagesToCheckBeforeMovingToNextUrl: ["invalid", "sufficient", "you have reached", "tomorrow", "wrong order", "locked", "was sent to your", "You have to wait", "Login not valid", "You have already claimed", "claimed successfully", "Claim not Valid", "rate limited"],
        antibotlinks: false
    }];

    // ===============================================================================================
    // المتغيرات العامة
    // ===============================================================================================

    let currentWebsiteIndex = 0;
    let isMovingToNextUrl = false;
    let isNextUrlReachable = false;
    let antibotlinksSolved = false;
    let currentConfig = {};
    let nextUrlData = {};
    let rotationInterval = null;

    // ===============================================================================================
    // وظائف المساعدة
    // ===============================================================================================

    // التحقق مما إذا كانت السلسلة تحتوي على أي من القيم في المصفوفة
    String.prototype.containsAny = function(arrayOfStrings) {
        if (!Array.isArray(arrayOfStrings)) {
            return this.toLowerCase().includes(arrayOfStrings.toLowerCase());
        }

        for (let i = 0; i < arrayOfStrings.length; i++) {
            if (this.toLowerCase().includes(arrayOfStrings[i].toLowerCase())) {
                return true;
            }
        }
        return false;
    };

    // إنشاء حدث HTML
    function triggerHTMLEvent(element, eventType) {
        try {
            const event = new Event(eventType, { bubbles: true });
            element.dispatchEvent(event);
        } catch (error) {
            console.error('Error triggering event:', error);
        }
    }

    // تأخير التنفيذ
    function delayExecution(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    // ===============================================================================================
    // تهيئة التكوين
    // ===============================================================================================

    function initializeWebsiteConfig() {
        for (const config of WEBSITE_CONFIG) {
            if (window.location.href.containsAny(config.website)) {
                currentConfig = { ...config };
                break;
            }
        }

        assignAddressToConfig();
    }

    function assignAddressToConfig() {
        let addressAssigned = false;

        // البحث عن العنوان المناسب بناءً على العملة في الرابط
        for (let i = 0; i < WEBSITE_LIST.length; i++) {
            const site = WEBSITE_LIST[i];
            if (site.url.includes(window.location.hostname) &&
                (window.location.href.includes("/" + site.coin + "/") ||
                 window.location.href.includes("/" + site.coin + "-") ||
                 window.location.href.endsWith("/" + site.coin))) {
                currentConfig.address = site.address;
                currentWebsiteIndex = i;
                addressAssigned = true;
                break;
            }
        }

        // إذا لم يتم العثور على العملة في الرابط، استخدام الإعداد الافتراضي
        if (!addressAssigned) {
            for (let i = 0; i < WEBSITE_LIST.length; i++) {
                const site = WEBSITE_LIST[i];
                if (site.url.includes(window.location.hostname)) {
                    if (site.regex) {
                        const storedRegex = GM_getValue("UrlRegex");
                        if (storedRegex === site.regex) {
                            currentConfig.address = site.address;
                            currentWebsiteIndex = i;
                            break;
                        }
                    } else {
                        currentConfig.address = site.address;
                        currentWebsiteIndex = i;
                        break;
                    }
                }
            }
        }
    }

    // ===============================================================================================
    // إدارة التنقل بين المواقع
    // ===============================================================================================

    async function getNextWebsiteUrl() {
        currentWebsiteIndex = (currentWebsiteIndex + 1) % WEBSITE_LIST.length;
        nextUrlData = WEBSITE_LIST[currentWebsiteIndex];

        // تخطي رابط Bitcoin إذا كان موجوداً
        if (nextUrlData.coin === "bitcoin-faucet") {
            currentWebsiteIndex = (currentWebsiteIndex + 1) % WEBSITE_LIST.length;
            nextUrlData = WEBSITE_LIST[currentWebsiteIndex];
        }

        if (nextUrlData.regex) {
            GM_setValue("UrlRegex", nextUrlData.regex);
        }

        await checkWebsiteAvailability(nextUrlData.url);
    }

    function checkWebsiteAvailability(websiteUrl) {
        return new Promise((resolve) => {
            GM_xmlhttpRequest({
                method: "GET",
                url: websiteUrl,
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                timeout: 2000,
                onload: function(response) {
                    isNextUrlReachable = (response && response.status === 200);
                    resolve();
                },
                onerror: function() {
                    isNextUrlReachable = false;
                    resolve();
                },
                ontimeout: function() {
                    isNextUrlReachable = false;
                    resolve();
                }
            });
        });
    }

    async function navigateToNextWebsite() {
        if (isMovingToNextUrl) return;

        isMovingToNextUrl = true;

        // إيقاف التدوير الحالي
        if (rotationInterval) {
            clearInterval(rotationInterval);
            rotationInterval = null;
        }

        do {
            await getNextWebsiteUrl();
            if (!isNextUrlReachable) {
                await delayExecution(2000);
            }
        } while (!isNextUrlReachable);

        window.location.href = nextUrlData.url;
    }

    // ===============================================================================================
    // وظيفة التدوير التلقائي الرئيسية
    // ===============================================================================================

    function startAutoRotation() {
        const rotationTime = 60000; // 60 ثانية بين كل انتقال

        // إيقاف أي تدوير موجود
        if (rotationInterval) {
            clearInterval(rotationInterval);
        }

        // بدء التدوير التلقائي
        rotationInterval = setInterval(() => {
            if (!isMovingToNextUrl) {
                navigateToNextWebsite();
            }
        }, rotationTime);
    }

    // ===============================================================================================
    // معالجة الكابتشا والمحتوى
    // ===============================================================================================

    function handleAntibotlinks() {
        let lastImg = "";
        const watcher = setInterval(() => {
            let img = document.querySelector('img[alt="captcha"], img[src*="captcha"], #captcha-image');
            if (img && img.src && img.src !== lastImg) {
                lastImg = img.src;
                fastSolve(img);
            }
        }, 120);

        function fastSolve(img) {
            try {
                const canvas = document.createElement("canvas");
                const ctx = canvas.getContext("2d");
                canvas.width = img.naturalWidth || img.width || 120;
                canvas.height = img.naturalHeight || img.height || 40;
                ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

                const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
                const data = imgData.data;

                let sum = 0, cnt = 0;
                for (let i = 0; i < data.length; i += 4) {
                    sum += data[i] + data[i + 1] + data[i + 2];
                    cnt++;
                }
                const avg = sum / cnt / 3;
                const thresh = Math.max(120, Math.min(160, avg));

                for (let i = 0; i < data.length; i += 4) {
                    let gray = (data[i] + data[i + 1] + data[i + 2]) / 3;
                    let v = gray > thresh ? 255 : 0;
                    data[i] = data[i + 1] = data[i + 2] = v;
                }
                ctx.putImageData(imgData, 0, 0);

                const text = readSimple(canvas);
                if (text && text.length >= 3) {
                    fillSimpleCaptcha(text);
                }
            } catch (e) {
                console.log("Fast ABLinks Error:", e);
            }
        }

        function readSimple(canvas) {
            const w = canvas.width;
            const h = canvas.height;
            const ctx = canvas.getContext("2d");
            const data = ctx.getImageData(0, 0, w, h).data;

            const cols = new Uint16Array(w);
            for (let x = 0; x < w; x++) {
                let count = 0;
                for (let y = 0; y < h; y++) {
                    const idx = (y * w + x) * 4;
                    if (data[idx] === 0) count++;
                }
                cols[x] = count;
            }

            const segs = [];
            let inSeg = false, start = 0;
            for (let x = 0; x < w; x++) {
                if (!inSeg && cols[x] > 2) {
                    inSeg = true;
                    start = x;
                }
                if (inSeg && cols[x] <= 2) {
                    inSeg = false;
                    segs.push([start, x]);
                }
            }
            if (inSeg) segs.push([start, w]);

            if (segs.length === 0) return "";

            const map = segs.map((s) => {
                const width = s[1] - s[0];
                if (width < 8) return "1";
                if (width < 12) return "7";
                if (width < 16) return "2";
                if (width < 19) return "3";
                if (width < 22) return "8";
                if (width < 26) return "A";
                return "X";
            });

            return map.join("").replace(/X/g, "").slice(0, 6);
        }

        function fillSimpleCaptcha(answer) {
            const cleaned = (answer || "").replace(/[^A-Za-z0-9]/g, "");
            if (!cleaned) return;
            const input = document.querySelector("input[name='captcha'], #captcha, input[name='code']");
            const btn = document.querySelector("button[type='submit'], input[type='submit'], #submit");
            if (input) {
                input.focus();
                input.value = cleaned;
                input.dispatchEvent(new Event("input", { bubbles: true }));
            }
            if (btn) btn.click();
        }
    }

    // ===============================================================================================
    // فحص الرسائل
    // ===============================================================================================

    function checkForMessages() {
        if (!currentConfig.allMessageSelectors) return false;

        for (const selector of currentConfig.allMessageSelectors) {
            const elements = document.querySelectorAll(selector);
            for (const element of elements) {
                if (element &&
                    (element.innerText.containsAny(currentConfig.messagesToCheckBeforeMovingToNextUrl) ||
                    (element.value && element.value.containsAny(currentConfig.messagesToCheckBeforeMovingToNextUrl)))) {
                    return true;
                }
            }
        }
        return false;
    }

    function checkForSuccessMessages() {
        if (!currentConfig.successMessageSelectors) return false;

        for (const selector of currentConfig.successMessageSelectors) {
            const elements = document.querySelectorAll(selector);
            for (const element of elements) {
                if (element && element.innerText.containsAny(currentConfig.messagesToCheckBeforeMovingToNextUrl)) {
                    return true;
                }
            }
        }
        return false;
    }

    // ===============================================================================================
    // معالجة النقر على الأزرار
    // ===============================================================================================

    function clickElement(selector, useFormSubmit = false) {
        const element = document.querySelector(selector);
        if (!element) return false;

        if (useFormSubmit && element.tagName === 'FORM') {
            element.submit();
        } else {
            element.click();
        }

        return true;
    }

    function handleDefaultButtons() {
        if (!currentConfig.defaultButtonSelectors) return;

        for (const selector of currentConfig.defaultButtonSelectors) {
            const button = document.querySelector(selector);
            if (button && !button.disabled && button.style.display !== 'none') {
                button.click();
                break;
            }
        }
    }

    function handleInputField() {
        const inputField = document.querySelector(currentConfig.inputTextSelector);
        if (!inputField || !currentConfig.address) return;

        inputField.value = currentConfig.address;
        inputField.dispatchEvent(new Event("input", { bubbles: true }));
        inputField.dispatchEvent(new Event("change", { bubbles: true }));

        setTimeout(() => {
            if (currentConfig.inputTextSelectorButton) {
                clickElement(currentConfig.inputTextSelectorButton);
            }
        }, 2000);
    }

    // ===============================================================================================
    // معالجة الكابتشا
    // ===============================================================================================

    function handleCaptchaSubmission() {
        let captchaSolved = false;

        const captchaInterval = setInterval(() => {
            if (currentConfig.antibotlinks && !antibotlinksSolved) {
                return;
            }

            // التحقق من reCAPTCHA
            if (!captchaSolved &&
                typeof grecaptcha !== 'undefined' &&
                grecaptcha.getResponse().length > 0 &&
                currentConfig.captchaButtonSubmitSelector) {

                const submitButton = document.querySelector(currentConfig.captchaButtonSubmitSelector);
                if (submitButton &&
                    submitButton.style.display !== 'none' &&
                    !submitButton.disabled) {

                    clickElement(currentConfig.captchaButtonSubmitSelector, currentConfig.formSubmit);
                    captchaSolved = true;

                    clearInterval(captchaInterval);

                    setTimeout(() => {
                        if (checkForMessages()) {
                            navigateToNextWebsite();
                        }
                    }, 20000);
                }
            }
        }, 2000);
    }

    // ===============================================================================================
    // الواجهة الرسومية المصغرة
    // ===============================================================================================

    function createMiniUI() {
        const uiContainer = document.createElement('div');
        uiContainer.id = 'faucet-rotator-mini-ui';
        uiContainer.style.cssText = `
            position: fixed;
            top: 10px;
            right: 10px;
            background: rgba(0, 0, 0, 0.85);
            color: white;
            padding: 6px 8px;
            border-radius: 4px;
            font-family: Arial, sans-serif;
            font-size: 10px;
            z-index: 10000;
            width: auto;
            max-width: 180px;
            box-shadow: 0 1px 5px rgba(0,0,0,0.3);
            border: 1px solid #4CAF50;
            line-height: 1.2;
            cursor: move;
            user-select: none;
        `;

        // جعل الواجهة قابلة للسحب
        let isDragging = false;
        let currentX;
        let currentY;
        let initialX;
        let initialY;

        uiContainer.addEventListener('mousedown', function(e) {
            isDragging = true;
            initialX = e.clientX - uiContainer.offsetLeft;
            initialY = e.clientY - uiContainer.offsetTop;
        });

        document.addEventListener('mousemove', function(e) {
            if (isDragging) {
                e.preventDefault();
                currentX = e.clientX - initialX;
                currentY = e.clientY - initialY;
                uiContainer.style.left = currentX + 'px';
                uiContainer.style.top = currentY + 'px';
                uiContainer.style.right = 'auto';
            }
        });

        document.addEventListener('mouseup', function() {
            isDragging = false;
        });

        const statusDot = document.createElement('span');
        statusDot.id = 'status-dot';
        statusDot.style.cssText = `
            display: inline-block;
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background-color: #4CAF50;
            margin-right: 3px;
            animation: pulse 1.5s infinite;
        `;

        const statusText = document.createElement('span');
        statusText.id = 'rotator-status-mini';
        statusText.textContent = 'Auto';
        statusText.style.cssText = `
            font-size: 9px;
            color: #4CAF50;
            font-weight: bold;
        `;

        const coinInfo = document.createElement('div');
        coinInfo.id = 'coin-info-mini';
        coinInfo.textContent = WEBSITE_LIST[currentWebsiteIndex]?.coin?.replace('-faucet', '').toUpperCase() || 'Unknown';
        coinInfo.style.cssText = `
            font-size: 9px;
            margin: 2px 0;
            font-weight: bold;
            color: #fff;
        `;

        const siteInfo = document.createElement('div');
        siteInfo.id = 'site-info-mini';
        siteInfo.textContent = `${currentWebsiteIndex + 1}/${WEBSITE_LIST.length}`;
        siteInfo.style.cssText = `
            font-size: 9px;
            color: #aaa;
        `;

        const buttonContainer = document.createElement('div');
        buttonContainer.style.cssText = `
            display: flex;
            gap: 2px;
            margin-top: 3px;
        `;

        const nextButton = document.createElement('button');
        nextButton.textContent = '▶';
        nextButton.title = 'Next Site';
        nextButton.style.cssText = `
            background: #4CAF50;
            color: white;
            border: none;
            padding: 2px 5px;
            border-radius: 2px;
            cursor: pointer;
            font-size: 9px;
            flex: 1;
        `;
        nextButton.onclick = () => {
            isMovingToNextUrl = false;
            navigateToNextWebsite();
        };

        const toggleButton = document.createElement('button');
        toggleButton.id = 'toggle-auto-mini';
        toggleButton.textContent = '⏸';
        toggleButton.title = 'Stop/Start Auto Rotation';
        toggleButton.style.cssText = `
            background: #FF9800;
            color: white;
            border: none;
            padding: 2px 5px;
            border-radius: 2px;
            cursor: pointer;
            font-size: 9px;
            flex: 1;
        `;
        toggleButton.onclick = () => {
            if (rotationInterval) {
                clearInterval(rotationInterval);
                rotationInterval = null;
                document.getElementById('status-dot').style.backgroundColor = '#f44336';
                document.getElementById('status-dot').style.animation = 'none';
                document.getElementById('rotator-status-mini').textContent = 'Stop';
                document.getElementById('rotator-status-mini').style.color = '#f44336';
                toggleButton.textContent = '▶';
            } else {
                startAutoRotation();
                document.getElementById('status-dot').style.backgroundColor = '#4CAF50';
                document.getElementById('status-dot').style.animation = 'pulse 1.5s infinite';
                document.getElementById('rotator-status-mini').textContent = 'Auto';
                document.getElementById('rotator-status-mini').style.color = '#4CAF50';
                toggleButton.textContent = '⏸';
            }
        };

        const hideButton = document.createElement('button');
        hideButton.textContent = '×';
        hideButton.title = 'Hide UI (Refresh page to show again)';
        hideButton.style.cssText = `
            background: #666;
            color: white;
            border: none;
            padding: 2px 5px;
            border-radius: 2px;
            cursor: pointer;
            font-size: 9px;
            flex: 0.5;
        `;
        hideButton.onclick = () => {
            uiContainer.style.display = 'none';
        };

        buttonContainer.appendChild(nextButton);
        buttonContainer.appendChild(toggleButton);
        buttonContainer.appendChild(hideButton);

        const headerDiv = document.createElement('div');
        headerDiv.style.cssText = `
            display: flex;
            align-items: center;
            margin-bottom: 3px;
        `;
        headerDiv.appendChild(statusDot);
        headerDiv.appendChild(statusText);

        uiContainer.appendChild(headerDiv);
        uiContainer.appendChild(coinInfo);
        uiContainer.appendChild(siteInfo);
        uiContainer.appendChild(buttonContainer);

        // إضافة أنيميشن النبض
        const styleSheet = document.createElement('style');
        styleSheet.textContent = `
            @keyframes pulse {
                0% { opacity: 1; }
                50% { opacity: 0.5; }
                100% { opacity: 1; }
            }
        `;
        document.head.appendChild(styleSheet);

        document.body.appendChild(uiContainer);

        // تحديث الواجهة بشكل دوري
        setInterval(() => {
            const coinInfoElement = document.getElementById('coin-info-mini');
            const siteInfoElement = document.getElementById('site-info-mini');
            const statusDotElement = document.getElementById('status-dot');
            const statusTextElement = document.getElementById('rotator-status-mini');

            if (coinInfoElement) {
                coinInfoElement.textContent = WEBSITE_LIST[currentWebsiteIndex]?.coin?.replace('-faucet', '').toUpperCase() || 'Unknown';
            }

            if (siteInfoElement) {
                siteInfoElement.textContent = `${currentWebsiteIndex + 1}/${WEBSITE_LIST.length}`;
            }

            if (statusDotElement && statusTextElement) {
                if (!rotationInterval) {
                    statusDotElement.style.backgroundColor = '#f44336';
                    statusDotElement.style.animation = 'none';
                    statusTextElement.textContent = 'Stop';
                    statusTextElement.style.color = '#f44336';
                } else if (isMovingToNextUrl) {
                    statusDotElement.style.backgroundColor = '#FF9800';
                    statusDotElement.style.animation = 'pulse 0.5s infinite';
                    statusTextElement.textContent = 'Next';
                    statusTextElement.style.color = '#FF9800';
                } else {
                    statusDotElement.style.backgroundColor = '#4CAF50';
                    statusDotElement.style.animation = 'pulse 1.5s infinite';
                    statusTextElement.textContent = 'Auto';
                    statusTextElement.style.color = '#4CAF50';
                }
            }
        }, 1000);
    }

    // ===============================================================================================
    // التهيئة الرئيسية
    // ===============================================================================================

    function initializeScript() {
        // تهيئة التكوين
        initializeWebsiteConfig();

        // إذا كان المستخدم يحاول الوصول إلى Bitcoin Faucet، انتقل مباشرة إلى الموقع التالي
        if (window.location.href.includes("/bitcoin-faucet/") ||
            window.location.href.includes("bitcoin-faucet")) {
            navigateToNextWebsite();
            return;
        }

        // الانتقال إلى الموقع التالي إذا كان العنوان غير صالح
        if (window.location.href.includes("to=FaucetPay") ||
            !currentConfig.address ||
            currentConfig.address.length < 5 ||
            currentConfig.address.includes("YOUR_")) {
            navigateToNextWebsite();
            return;
        }

        // بدء التدوير التلقائي
        startAutoRotation();

        // معالجة النوافذ
        if (window.name === "nextWindowUrl") {
            window.name = "";
            navigateToNextWebsite();
            return;
        } else {
            window.name = window.location.href;
        }

        // بدء التنفيذ بعد تأخير
        setTimeout(() => {
            // معالجة الروابط المضادة للبوت
            if (currentConfig.antibotlinks) {
                handleAntibotlinks();
            }

            // تنفيذ وظائف إضافية إذا كانت موجودة
            if (currentConfig.additionalFunctions) {
                currentConfig.additionalFunctions();
            }

            // فحص الرسائل والانتقال إذا لزم الأمر
            if (!isMovingToNextUrl && checkForMessages()) {
                navigateToNextWebsite();
                return;
            }

            // معالجة حقل الإدخال
            if (!isMovingToNextUrl && currentConfig.inputTextSelector) {
                handleInputField();
            }

            // النقر على الأزرار الافتراضية
            if (!isMovingToNextUrl) {
                handleDefaultButtons();
            }

            // معالجة الكابتشا
            handleCaptchaSubmission();
        }, 2000);

        // إنشاء واجهة المستخدم المصغرة
        setTimeout(() => {
            createMiniUI();
        }, 3000);
    }

    // بدء التنفيذ
    initializeScript();

})();