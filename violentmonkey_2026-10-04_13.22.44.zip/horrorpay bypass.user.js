// ==UserScript==
// @name horrorpay bypass
// @match https://aradmag.online/go.php*
// @match https://horrorpay.online/*
// @grant none
// ==/UserScript==

(function(){setInterval(()=>{if(typeof adClicked!=='undefined'&&!adClicked){window.adClicked=true;if(typeof startCountdown==='function')startCountdown();}if(typeof countdown!=='undefined')window.countdown=0;let b=document.getElementById('continueBtn')||document.getElementById('offerContinueBtn');if(b){b.disabled=false;b.click();}},1000);})();