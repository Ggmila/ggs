// ==UserScript==
// @name         MCaptcha Auto-Solver (OnlyFaucet)
// @namespace    http://tampermonkey.net/
// @version      1.3
// @author       Shnethan
// @description  Auto-solves mCaptcha
// @match        https://onlyfaucet.com/faucet/*
// @icon         https://www.solflare.com/tkn_lnd_pg_assets/favicons/favicon.ico
// @license      © Shnethan
// @grant        none
// @run-at       document-idle
// @downloadURL https://update.greasyfork.org/scripts/578964/MCaptcha%20Auto-Solver%20%28OnlyFaucet%29.user.js
// @updateURL https://update.greasyfork.org/scripts/578964/MCaptcha%20Auto-Solver%20%28OnlyFaucet%29.meta.js
// ==/UserScript==
 
         /*
                 * Copyright (c) 2026 Shnethan . All rights reserved.
         */

(async function() {

    'use strict';

    const w = s => new Promise(r => {
        let e = document.querySelector(s);
        if (e) return r(e);
        new MutationObserver((_, o) => {
            if (e = document.querySelector(s)) { o.disconnect(); r(e); }
        }).observe(document.body, { childList: true, subtree: true });
    });

    try {
        (await w('#mcaptcha-checkbox-box')).click();
        const c = await w('#mcaptcha-canvas');
        await new Promise(r => setTimeout(r, 1e3));

        const t = c.getContext('2d'), u = c.width / 5, a = [];
        for (let i = 0; i < 5; i++) {
            const d = t.getImageData(~~(i * u + u / 2 - 5), ~~(c.height / 2 - 5), 10, 10).data;
            let n1 = 0, n2 = 0, n3 = 0;
            for (let j = 0; j < d.length; j += 4) { n1 += d[j]; n2 += d[j + 1]; n3 += d[j + 2]; }
            a.push([n1, n2, n3]);
        }

        let m = -1, k = 0;
        for (let i = 0; i < 5; i++) {
            let l = 0;
            for (let j = 0; j < 5; j++) if (i !== j) l += Math.abs(a[i][0] - a[j][0]) + Math.abs(a[i][1] - a[j][1]) + Math.abs(a[i][2] - a[j][2]);
            if (l > m) { m = l; k = i; }
        }

        const e = document.getElementById('mcaptcha-indicator');
        if (e) { e.style.left = k * 20 + '%'; e.style.display = 'block'; }

        await new Promise(r => setTimeout(r, 4e3));

        const g = c.getBoundingClientRect();
        c.dispatchEvent(new MouseEvent('click', {
            clientX: g.left + k * g.width / 5 + g.width / 10,
            clientY: g.top + g.height / 2,
            bubbles: 1, cancelable: 1
        }));

        const q = await w('#mcaptcha-confirm-btn');
        if (q) {
            q.dispatchEvent(new PointerEvent('pointerdown', { bubbles: 1 }));
            setTimeout(() => q.click(), 150);
        }
    } catch (e) {}
})();